@echo off

color 34

Echo Ceci va d�sinstaller ET_Config mais aussi supprimer tout les fichier .cfg
Echo qui ce trouve dans etmain.
Echo.
Echo.
pause
Echo.
Echo.
Echo.
Echo Etes-vous s�r de vouloir continuer ?
Echo.
Echo.
Echo.
pause
RD /s /q "..\etmain\Message"
RD /s /q "..\etmain\Option"
RD /s /q "..\etmain\Script"
del ..\etmain\*.cfg
