@echo off

color 34


Echo Ceci va faire un backup de tout les fichier cfg de etmain et etrpro 
Echo dans un r�pertoire backup � la racine du jeu :
Echo.
Echo.
Echo.
@pause


MD "..\Backup\etmain"
MD "..\Backup\etpro"


xcopy "..\etmain\*.cfg" "..\Backup\etmain"

xcopy "..\etpro\*.cfg" "..\Backup\etpro