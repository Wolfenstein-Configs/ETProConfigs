@echo off

color 34


Echo Ceci va installer ET_config :
Echo.
Echo.
Echo.
@pause


xcopy "Autoexec\Map\*.cfg" "..\etmain" /q /y


xcopy "Autoexec\Classe\*.cfg" "..\etmain" /q /y

xcopy "Autoexec\*.cfg" "..\etmain" /q /y

xcopy "Autoexec\Perso\*.cfg" "..\etmain" /q /y

xcopy "%cd%" "..\etmain" /s /q /exclude:noinstalle.txt /y

