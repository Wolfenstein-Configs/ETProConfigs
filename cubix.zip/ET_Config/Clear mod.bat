@echo off


echo Ceci supprimeras tous les .cfg et .tmp des mods etpro/etmain/shrubet.


@pause

del ..\etpro\*.cfg

del ..\shrubet\*.cfg

del ..\etmain\*.cfg




del ..\etpro\*.tmp

del ..\shrubet\*.tmp

del ..\etmain\*.tmp