// #mad0r
//------------------------------------------------------------------------------------------------------------
// Bugreport: eMail: mad0r@arcor.de or msg me in #et-scene @ Quakenet
//------------------------------------------------------------------------------------------------------------
// � Copyright by mad0r
//------------------------------------------------------------------------------------------------------------
// Version 1.2 Final!
//------------------------------------------------------------------------------------------------------------
// readme.txt
//------------------------------------------------------------------------------------------------------------


// History of my Config ��
//------------------------------------------------------------------------------------------------------------

	After I have been playing Enemy Territory for 2 or 3 weeks, I startet to search for a good 
	Config in the Internet. On a very nice site about my favourite game, i found the Config
	which was the foundation for my current Config (Version 1.1).
	In course of time I increased my knowledge about scripting and so I could optimize the 
	grafic-settings for my personal requirements, also I added voice-bindings and the first 
	classscript.
	Now, in the Version 1.1, the grafic-settings are complete, so in the next time I only will
	change some colors or add/delete some crap scripts :)

// Version 1.0 - Changelog ��
//------------------------------------------------------------------------------------------------------------

	� the grafics are now final
	� added new autoexec's for all standart maps and some custom maps (Supplydepot2, sw_goldrush_te and
	  a autoexec_default.cfg)
	� also added autoexec's for each class (axis, allies)
	� fit in a new spawnpointscript based on the autoexec_allies.cfg and autoexec_axis.cfg

// Version 1.1 - Changelog ��
//------------------------------------------------------------------------------------------------------------

	� i deleted some crap voice-bindigs and changed the style (other colors and signs)
	� some bindings changed

// Version 1.2 - Changelog ��
//------------------------------------------------------------------------------------------------------------

	� i changed the grafics for fueldump and railgun because of bad experiences with the old ones, 
	  i hope the new settings are better :)
	� and i improved some style bugs and added some new greetings
	� added the cmd wait 100 to my autoexec.cfg to prevent the 'valid cd key' s***

// Sripts I use ��
//------------------------------------------------------------------------------------------------------------

	� demo_toggle
	� stats_toggle
	� name_toggle
	� autoaction_toggle (public and clanwar settings)
	� etpro_spawntimer_script
	� prone_script
	� hud_toggle (for demos)
	� pause_toggle
	� buddyselect-toggle (fireteam)
	� selfkill_script 
	� class_script
	� spawnpoint_script
	� spawntimer_script made by aT|Meffen

// some greetings ��
//------------------------------------------------------------------------------------------------------------

	� to the whole #cs3r-clan 	/ 	www.cs3r.com	| #cs3r @ Quakenet
	� to the whole #sfto-clan 	/ 	www.sfto.de     | #sfto @ Quakenet
	� to my ex clan #wdc 		/ 	www.wdc-clan.de | #wdc-clan @ Quakenet
	� to the whole et-scene staff 	/ 	www.et-scene.de | #et-scene @ Quakenet
	� to all Liga4Fun-Admins	/	www.liga4fun.de | #liga4fun @ Quakenet
	� and some personal greetings:	� nippel
					� vaXx
					� wdc-mike
					� wdc-MeisterEder
					� mfn
					� pitri
					� ebaS
					� Mueck3
					� zerender
					� maja
					� HoLLa
					� diZe
					� juiCE