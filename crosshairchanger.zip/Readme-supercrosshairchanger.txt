 _____________________________
|=============================|
|  Script downloaded from     |
| http://etcfg.revo-online.nl |
|=============================|

 Using
===========================
Change the complete crosshair settings with 2 buttons without going to Options!
Page up: Crosschange
Page Down: Crosssetting


 Installation
===========================
Copy the script out of the download and place it in your autoexec.cfg.

Dont have an autoexec.cfg yet?
http://etcfg.revo-online.nl/faq.php?cat_id=1


|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
If you like this download, please support us by clicking Google Ads on our website.
|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||