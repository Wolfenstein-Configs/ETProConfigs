Lake's config (Team Massacre - www.team-massacre.nl)
Last updated: 19/11/2004 16.00cet

Readme
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

After building a config builder upon my own experiences with
making configs, I decided to give out my own config publicly.
Except for the graphics basicly every config has nowadays, it
also includes some scripts that might be interesting for some
people (most will only work in etpro 3.0.0 or higher):

   - A 5-key class-selectionscript without side-select
   - A 2-key spawnscript without mapselect
   - Fov & sensitivity switch
   - pmove_fixed toggle
   - Per map special action (1 key for the most used/important
     action on that map)
   - Autoaction switch (switch autorecording of demos/screens
     on/off)

Last but not least it also includes a fully customized etpro HUD.


Installation instructions
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
Copy all files into the "ET/etmain"-directory. Edit the
"binds.cfg" file and adjust it to your own suits (this file is
the most important one in this package, all binds/scripts are
defined here). Start ET, open the console (key under ESC, 
above TAB) and type "/exec lake".


List of files
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
binds.cfg:	Most important file, contains almost all binds
		and scripts.
nick.cfg:	Nickname is defined in here
lake.cfg:	Cvars-configfile (gfx, sound, hud)
autoexec.cfg:	Auto-executes binds.cfg when ET is started

autoexec_<mapname>.cfg:	Defines the "specialaction" and the
			spawnplaces/spawntimes for a specific map
autoexec_<class>.cfg:	Defines some class-specific binds

Final notes
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
Have fun with the config, but be sure to make a backup of
your current config.

Lake
Team Massacre - #massacre (Qnet) - www.team-massacre.nl
http://lakedrake.boxke.be/ (Config Builder)