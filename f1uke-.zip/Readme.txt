----------------------------------
f1uke's ET config 8/11/05
----------------------------------

Updates from last config:
-----------------------
- Fixed bug with class selector, it didn't always work correctly
- Improved spawntimer, now it's a lot smarter and works properly
- More useful config screenshot


How to install:
-----------------------
Put everything in your etpro folder. Backup your old ET config if you feel the crap you have in your etmain/etpro folders right now is worth anything.


How to use the class selector:
-----------------------
It's pretty simple really. To join the axis team, press f4 then press a class button. To join the allied team, press f5 then a class button. To go into spectator mode, press f3. The class buttons are defined as follows:

f6:  covert sniper (press once for rifle, twice for fg42)
f7:  engineer (press once for smg engy, twice for noobstick engy)
f8:  explosives soldier (press once for panzer, twice for mortar)
f9:  medic
f10: field ops
f11: covert with sten
f12: misc soldier (press once for mobile mg, twice for flamethrower)

This class script is not affected by stopwatch team switches or anything of the sort, so don't worry about accidentally switching teams mid-round because you have an inferior class script. Also note that all class buttons get reset each time you choose a class, so there's no guesswork in selecting your class. Finally, you might have wanted to be able to select soldier smg with this script. Well too fucking bad, I don't waste time like that. :(


How to use the spawntimer:
-----------------------
For most comp maps, spawntime intervals should be already set. Just enter the spawntime on your keyboard (NOT with the keypad numbers--the other ones), then press '+' next to backspace to spam the time to you teammates. To clear the spawntime so you can enter another, press '-'. If the spawntime intervals aren't automatically set, you must press one of the following keys before entering a number or else it won't work:

p: 15 second enemy spawn interval
[: 20 second enemy spawn interval
]: 30 second enemy spawn interval


How to use the spawn selector:
-----------------------
Press 'i' to cycle through spawns. Only useful spawnpoints were included, so you can't spawn at the villa on radar or the first allied spawn on oasis using this script.


Well that's about all I have to say, enjoy the config! Any questions, comments, insults, whatever, you can find me at #pubstar on quakenet. Cya! :)
