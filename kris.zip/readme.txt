Sorry that my cfg is a big mess ;)
If u want to completely see how it looks like for me then:

- exec 1 first
- then exec 2
- then exec 3
- then exec 4 (when ur smallscreen only, it loads fullscreen)
- then exec 5 for class script.

Make sure your monitor can handle 120hz @ r_mode 6, otherwise your screen might turn into a black screen ;o

extra info:

- qpad
- mouse bungee
- decent pc for almost stable 125 fps
- mx518 on 1000hz and 1600dpi
- iiyama vision master pro 514 22inch ;>
- windows sens 5, i need around 22cm moving the mouse from left to right or the other way around for a 180 turn ingame.

						5-1-2006



