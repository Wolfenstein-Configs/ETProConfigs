Settings:

Resolution: 800x600
Ingame sensitivity: 4.0
Windows sensitivity: 6/11
Mouse accel: off
Monitor refresh rate: 120 Hz