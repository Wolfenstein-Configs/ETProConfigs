1. Put autoexec.cfg in your C:\Programms\Wolfenstein - Enemy Territory\etmain || Just put into Etmain folder

2. Go to any Server, open console with "^" and do /exec autoexec.cfg

3. Enjoy Headshots


PS: Please dont tell anyone but I've stolen his Config. He was AFK, I was by him. I put the CFG in my USB and stole it :P
