  ________                              ___       __      __      __      
 /\_____  \                           /'___`\   /'__`\  /'__`\  /'_ `\    
 \/____//'/'    ___      __          /\_\ /\ \ /\ \/\ \/\ \/\ \/\ \L\ \   
      //'/'    / __`\  /'__`\ _______\/_/// /__\ \ \ \ \ \ \ \ \ \___, \  
     //'/'___ /\ \L\ \/\  __//\______\  // /_\ \\ \ \_\ \ \ \_\ \/__,/\ \ 
     /\_______\ \____/\ \____\/______/ /\______/ \ \____/\ \____/    \ \_\
     \/_______/\/___/  \/____/         \/_____/   \/___/  \/___/      \/_/


Inhalt:

>>>> Grafik und Settings angepasst
>>>> Spawnscript (einfaches durchswitchen der Spawnpoints mit der Taste Kp_INS)
>>>> Klassenscript (5 Tastenauswahl einschliesslich Waffenwahl)
>>>> verschiedene mehr oder weniger nützliche Scripts bzw Toggle (strafe,volume.. etc)

Für ETmain: configs (kompletter Ordner)
            autoexec_allies.cfg
            autoexec_axis.cfg
            
Für ETpro:  alle Mapspezifische Configs

Viel Spass beim Modifizieren.